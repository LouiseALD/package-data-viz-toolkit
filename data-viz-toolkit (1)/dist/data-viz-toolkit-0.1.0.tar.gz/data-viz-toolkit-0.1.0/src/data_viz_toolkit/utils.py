def format_title(title):
    return title.strip().title()
