"""
DataViz Toolkit: Um pacote de visualização e análise de dados.
"""
